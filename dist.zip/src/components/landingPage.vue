<template>
  <v-parallax
    dark
    src="https://www.elsetge.cat/myimg/f/13-134034_black-and-white-dog-wallpaper-dog-wallpaper-black.jpg"
    height="700"
  >
    <v-row
      align="center"
      justify="center"
    >
      <v-col class="text-center" cols="12">
        <h1 class="display-1 font-weight-thin mb-4">Welcome to Kouvee Pet Shop</h1>
        <!-- <h4 class="subheading">Build your application today!</h4> -->
        <v-btn rounded color="primary" dark router to="/home">Go to Home</v-btn>
      </v-col>
    </v-row>
  </v-parallax>
</template>
