module.exports = {
  lintOnSave: false,
  "transpileDependencies": [
    "vuetify"
  ],
  // devServer: {

  //   host: 'localhost'
  //   }
}